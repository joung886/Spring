package com.dw.repatori;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepatoriApplicationTests {

	@Test
	void contextLoads() {
	}

}
