package com.dw.projectoneapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectoneappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectoneappApplication.class, args);
	}

}
