package com.dw.projectoneapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectoneappApplicationTests {

	@Test
	void contextLoads() {
	}

}
