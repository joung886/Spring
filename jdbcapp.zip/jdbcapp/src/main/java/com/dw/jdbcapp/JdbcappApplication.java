package com.dw.jdbcapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcappApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcappApplication.class, args);
	}

}
